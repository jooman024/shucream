package beans;

public class PlaceBean {

	private String placeBig;
	private String placeSma;
	
	
	public String getPlaceBig() {
		return placeBig;
	}
	public void setPlaceBig(String placeBig) {
		this.placeBig = placeBig;
	}
	public String getPlaceSma() {
		return placeSma;
	}
	public void setPlaceSma(String placeSma) {
		this.placeSma = placeSma;
	}
	
	
}
