package beans;

public class JJimBean {
	private String jjimName;
	private String jjimDate;
	private int jjimCount;
	private int jjimPrice;
	private String jjimGoodsState;
	private String jjimNoteState;
	private String jjimState;
	private String jjimid;
	
	
	public String getJjimid() {
		return jjimid;
	}
	public void setJjimid(String jjimid) {
		this.jjimid = jjimid;
	}
	public String getJjimName() {
		return jjimName;
	}
	public void setJjimName(String jjimName) {
		this.jjimName = jjimName;
	}
	public String getJjimDate() {
		return jjimDate;
	}
	public void setJjimDate(String jjimDate) {
		this.jjimDate = jjimDate;
	}
	public int getJjimCount() {
		return jjimCount;
	}
	public void setJjimCount(int jjimCount) {
		this.jjimCount = jjimCount;
	}
	public int getJjimPrice() {
		return jjimPrice;
	}
	public void setJjimPrice(int jjimPrice) {
		this.jjimPrice = jjimPrice;
	}
	public String getJjimGoodsState() {
		return jjimGoodsState;
	}
	public void setJjimGoodsState(String jjimGoodsState) {
		this.jjimGoodsState = jjimGoodsState;
	}
	public String getJjimNoteState() {
		return jjimNoteState;
	}
	public void setJjimNoteState(String jjimNoteState) {
		this.jjimNoteState = jjimNoteState;
	}
	public String getJjimState() {
		return jjimState;
	}
	public void setJjimState(String jjimState) {
		this.jjimState = jjimState;
	}
	
	
}
